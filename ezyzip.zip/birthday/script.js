var a=prompt("Enter UserName");
 var b=prompt("Enter password");
  	if(a== "tanuj" && b=="harshi")
  	{
  	    window.location.href="start.html";
  	}
  	else
  	{
  		alert("invalid details");
  		window.location.href="index.html";
  	}
  	